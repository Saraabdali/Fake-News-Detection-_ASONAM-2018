function [label,idxnl] = createSampleLabel3(label3,plabel) 
    lnews=size(label3,1);%(news(1:500,:),1);
    k = ceil(plabel*lnews);
    labelInd= label3; % news.label3+1;%label3(1:500,:) +1;
    labelInd(labelInd==0) =-1;
    %labelInd(labelInd==1) =0.5;
    %pseudopriors:
    %real news =1
    %fake news =-1
    [y,idx] = datasample(labelInd,k,'Replace',false);
    label = zeros(lnews,1);
    label(idx')=y;
    idxnl=find(label==0);
end
