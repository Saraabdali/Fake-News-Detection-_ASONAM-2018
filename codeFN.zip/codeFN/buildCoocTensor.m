function [wxwxn,wxwxnF,wxwxnL] =buildCoocTensor(nnews,ldic)
myFolder = './IndicesTemp/';
filePattern = fullfile(myFolder, 'subIndNewsVals_*.mat');
matFiles = dir(filePattern);
subInd = cell( length(matFiles),1);
vals = cell( length(matFiles),1);
valslog = cell( length(matFiles),1);
for k = 1:length(matFiles)
  baseFileName = matFiles(k).name;
  fullFileName = fullfile(myFolder, baseFileName);
  fprintf(1, 'Reading %s\n', baseFileName);
  load(fullFileName);
  subInd{k,1}=subIndNews;
  vals{k,1}=valsNews; %remove log 
  valslog{k,1}=log(valsNews);
  clear subIndNews;
  clear valsNews;
end
tic
subInd=vertcat(subInd{:});
vals=vertcat(vals{:});
valslog=vertcat(valslog{:});
disp('concatenation finished');
toc
tic
wxwxn=sptensor(subInd,1,[ldic,ldic,nnews]);
wxwxnF=sptensor(subInd,vals,[ldic,ldic,nnews]);
wxwxnL=sptensor(subInd,valslog,[ldic,ldic,nnews]);
rmdir('IndicesTemp', 's');
disp('sptensor finished');
end
